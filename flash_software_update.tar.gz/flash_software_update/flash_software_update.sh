#!/bin/bash
python ./bin/reverse_tcp.py
